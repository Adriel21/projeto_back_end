<?php
ob_start();

use Projeto\ControleDeAcesso;
use Projeto\Usuario;

require_once '../vendor/autoload.php';
$sessao = new ControleDeAcesso;
if(isset($_GET['exclui'])){




$profissao->setUsuarioId($_SESSION['id']);

$usuario = new Usuario;
$usuario->setId($_SESSION['id']);
$usuario->excluirCadastro();



$sessao->logout();
} else {
    header('location:dashboard_cliente.php?acesso_restrito');
}





<?php
ob_start();

use Projeto\ControleDeAcesso;
use Projeto\Profissao;
use Projeto\Usuario;

require_once '../vendor/autoload.php';
$sessao = new ControleDeAcesso;

$profissao = new Profissao;

$profissao->setUsuarioId($_SESSION['id']);

$profissao->excluirFreela();
$usuario = new Usuario;
$usuario->setId($_SESSION['id']);
$dados = $usuario->listarUm();
$sessao->logout();










